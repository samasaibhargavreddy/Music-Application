package com.PlayForYouApp.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlayForYouAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlayForYouAppApplication.class, args);
	}

}
